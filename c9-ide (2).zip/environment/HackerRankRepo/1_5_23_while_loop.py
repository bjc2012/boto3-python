# 1) For all non-negative integers , print i squared if less than n

n = 5
    
i = 0
while (i < n):
        print(i * i)
        i += 1
